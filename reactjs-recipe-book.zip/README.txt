A Pen created at CodePen.io. You can find this one at https://codepen.io/kristarling/pen/wGGpVW.

 A simple Reactjs recipe app with local storage to save your changes